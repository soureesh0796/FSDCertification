export class User {
    userId:string;
    password:string;
    firstName:string;
    lastName:string;
}
