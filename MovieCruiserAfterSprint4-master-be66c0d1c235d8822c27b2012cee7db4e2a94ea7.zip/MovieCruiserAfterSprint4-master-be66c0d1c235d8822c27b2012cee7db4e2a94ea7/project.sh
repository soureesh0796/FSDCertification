cd MovieCruisorAuthenticationService
source ./env-variable.sh
cd ..
cd MovieCruisorBackend
source ./env-variable.sh
cd ..

