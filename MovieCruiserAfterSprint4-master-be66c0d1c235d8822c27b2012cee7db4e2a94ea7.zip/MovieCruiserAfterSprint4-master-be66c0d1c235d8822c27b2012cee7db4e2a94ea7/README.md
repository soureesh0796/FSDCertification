Movie Cruiser Application where you can watch your favourite movies.
