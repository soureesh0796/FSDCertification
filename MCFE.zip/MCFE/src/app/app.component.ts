import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
  <mat-toolbar color="primary">
   <span>Movie Cruiser</span>
   <button mat-button [routerLink]="['/movies/popular']">Popular Movies</button>
   <button mat-button [routerLink]="['/movies/top_rated']">Top-Rated Movies</button>
   <button mat-button [routerLink]="['/movies/watchlist']">My Watchlist</button>
   <button mat-button [routerLink]="['/movies/search']">Search</button>
  </mat-toolbar>
  <router-outlet></router-outlet>
  `,
  styles: []
})
export class AppComponent {
  title = 'MovieCruiserFrontEnd';
}
