import { Component, OnInit, Input, EventEmitter, Output } from '@angular/core';
import { Movie } from '../../movie';
import { MovieService } from '../../movie.service';
import { MatSnackBarModule, MatSnackBar } from '@angular/material/snack-bar';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';

import { DialogComponent } from '../dialog/dialog.component';

@Component({
  selector: 'movie-thumbnail',
  templateUrl: './thumbnail.component.html',
  styleUrls: ['./thumbnail.component.css']
})
export class ThumbnailComponent implements OnInit {

  @Input()
  movie: Movie;

  @Input()
  useWatchlistApi: boolean;

  @Output()
  addMovie = new EventEmitter();

  @Output()
  deleteMovie = new EventEmitter();

  @Output()
  updateMovie = new EventEmitter();

  constructor( private snackBar: MatSnackBar, private dialog: MatDialog) {
   }

  ngOnInit() {}

  addToWatchlist() {
    this.addMovie.emit(this.movie);
  }

  deleteFromWatchlist() {
    this.deleteMovie.emit(this.movie);
  }

  updateWatchlist(actionType) {
    let dialogRef = this.dialog.open(DialogComponent, {
      width: '400px',
      data: {obj: this.movie, actionType: actionType}
    });
    dialogRef.afterClosed().subscribe(result => {
    });
  }

}