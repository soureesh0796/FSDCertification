import { Component, OnInit, Input } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { MatSnackBarModule, MatSnackBar } from '@angular/material/snack-bar';


import { Movie } from '../../movie';
import { MovieService } from '../../movie.service';

@Component({
  selector: 'movie-container',
  templateUrl: './container.component.html',
  styleUrls: ['./container.component.css']
})
export class ContainerComponent implements OnInit {

  @Input()
  movies: Array<Movie>;

  @Input()
  useWatchlistApi: boolean;

  constructor(private movieService: MovieService, private snackBar: MatSnackBar) { 
  }

  ngOnInit() {
  }

  addToWatchlist(movie) {
    let message = `${movie.title} added to watchlist`;
    console.log("movie title", movie.title);
    this.movieService.addMovieToWatchlist(movie)
    .subscribe((movie) => {
      this.snackBar.open('Movie added to Watchlist!', '', {
        duration:1000
      });
    });
  }

  deleteFromWatchlist(movie) {
    let message = `${movie.title} deleted from your watchlist`;
    for (var i = 0; i < this.movies.length; i++) {
      if (this.movies[i].title === movie.title) {
        this.movies.splice(i,1);
      }
    }
    this.movieService.deleteFromWatchlist(movie).subscribe((movie) => {
      this.snackBar.open(message, '', {
        duration: 2000
      });
    });
  }

}
