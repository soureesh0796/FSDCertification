import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'; 
import { map } from 'rxjs/operators';
import { Observable } from 'rxjs';

import { Movie } from './movie';

@Injectable()
export class MovieService {

  tmbdEndPoint: string;
  imagePrefix: string;
  apiKey: string;
  watchlistEndPoint: string;
  springEndPoint: string;

  constructor(private http: HttpClient) {
    this.apiKey = 'api_key=4f5ef5c928dea6df91088949785e0171'
    this.tmbdEndPoint = "https://api.themoviedb.org/3/movie";
    this.imagePrefix = "https://image.tmdb.org/t/p/w500";
    this.watchlistEndPoint = "http://localhost:3000/watchlist";
    this.springEndPoint = "http://localhost:8094/api/moviecruise";
   }
   
   getMovies(type: string, page: number = 1): Observable<Array<Movie>> {
     const endPoint = `${this.tmbdEndPoint}/${type}?${this.apiKey}&page=${page}`;
     return this.http.get(endPoint).pipe(
      map(this.pickMovieResults),
      map(this.transformPosterPath.bind(this))
    );
   }

   transformPosterPath(movies): Array<Movie> {
    return movies.map(movie => {
      movie.poster_path = `${this.imagePrefix}${movie.poster_path}`;
      console.log(movie.poster_path);
      return movie;
    });
   }

   pickMovieResults(response) {
    return response['results'];
   }

   addMovieToWatchlist(movie) {
      return this.http.post(this.springEndPoint,movie);
   }

   getWatchlistedMovies(): Observable<Array<Movie>> {
      return this.http.get<Array<Movie>>(this.springEndPoint);
   }

   deleteFromWatchlist(movie: Movie) {
    const url = `${this.springEndPoint}/${movie.id}`;
    return this.http.delete(url,{responseType: 'text'});
   }

   updateComments(movie) {
    const url = `${this.springEndPoint}/${movie.id}`;
    return this.http.put(url, movie);
   }

   searchMovie(searchKey: string,page: number = 1): Observable<Array<Movie>> {
    if (searchKey.length > 0) {
      const searchEndpoint = `${this.tmbdEndPoint}/search/movie?${this.apiKey}&page=${page}&query=${searchKey}`;
      return this.http.get(searchEndpoint).pipe(
        map(this.pickMovieResults),
        map(this.transformPosterPath.bind(this))
      );
    }
  }

}
