import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';

import { ThumbnailComponent } from './components/thumbnail/thumbnail.component';
import { MovieService } from './movie.service';
import { ContainerComponent } from './components/container/container.component';
import { MovieRouterModule } from './movie-router.module';


@NgModule({
  declarations: [ThumbnailComponent, ContainerComponent],

  imports: [
    CommonModule,
    HttpClientModule,
    MovieRouterModule
  ],
  exports: [
    MovieRouterModule,
    ThumbnailComponent,
  ],
  providers: [
    MovieService
  ]
})
export class MovieModule { }
