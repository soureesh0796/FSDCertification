import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'; 
import { map } from 'rxjs/operators';
import { Observable } from 'rxjs';

import { Movie } from './movie';

@Injectable()
export class MovieService {

  tmbdEndPoint: string;
  imagePrefix: string;
  apiKey: string;

  constructor(private http: HttpClient) {
    this.apiKey = 'api_key=4f5ef5c928dea6df91088949785e0171'
    this.tmbdEndPoint = "https://api.themoviedb.org/3/movie";
    this.imagePrefix = "https://image.tmdb.org/t/p/w500";
   }
   
   getMovies(type: string, page: number = 1): Observable<Array<Movie>> {
     const endPoint = `${this.tmbdEndPoint}/${type}?${this.apiKey}&page=${page}`;
     return this.http.get(endPoint).pipe(
      map(this.pickMovieResults),
      map(this.transformPosterPath.bind(this))
    );
   }

   transformPosterPath(movies): Array<Movie> {
    return movies.map(movie => {
      movie.poster_path = `${this.imagePrefix}${movie.poster_path}`;
      console.log(movie.poster_path);
      return movie;
    });
   }

   pickMovieResults(response) {
    return response['results'];
   }
}
